#Set up ADXL45 Accelerometer

##Connection to Arduino

Use the schematics found here:
<http://codeyoung.blogspot.com/2009/11/adxl345-accelerometer-breakout-board.html>

##Add Libraries
In the **Arduino Software**
1. go to Sketch
2. Import Library...
3. Choose the folder **Example Code** from the **Accelerometer code** folder in our git hub repository.

###Now you can run:
 **xyz_out.in0**
 **pitch_roll.ino**