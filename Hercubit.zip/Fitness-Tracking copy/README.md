#Hercubit
================

**This version will not connect to a device. It will show archive data when you start an exercise.** 
###To run



*If you want a demo with device, please contact us*

Mac OSX - run Hercubit.app
Windows:

* Install Python 2.7
* Run app.py in python shell (e.g. ``$ python app.py``)



###Abstract
Hercubit is a wristband that keeps track of your arm exercises and can even show you real-time feedback on a computer screen.



This is a **Final Project for MIMS** at **UC Berkeley**

###Contact

<http://www.facebook.com/hercubit>


**Team**

Name|Email
-----|----
Morgan Wallace|morgan.m.wallace@gmail.com
Charles Wang|charleswang007@gmail.com
Kate Hsiao|kamebkj@gmail.com
Shaohan Chen|shaohan.chen@berkeley.edu



