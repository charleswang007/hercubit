var status = "none";


$(document).ready(function(){
    // var socket = io.connect('http://' + document.domain + ':' + location.port + '/test');
    // $("#gif").hide();
    // $("#graph").hide();

    // 1. Start button clicked triggers the bluetooth_conn function on app.py 
    $('#startbtn').click(function(event) {
        if ($('#startbtn').html()=='Done'){
            $("#new_block").attr("id","");
            $("#connection_status").html('');
            // console.log($("#chosen-goal .goal_count").text());
            // console.log($("#count_denomenator").html());
            // $("#startbtn").prop('disabled', function (_, val) { return ! val; });
            // $("#startbtn").addClass("disable");
            console.log("Searching bluetooth for Hercubit");
            $("#readysetgo").text('Get ready...')
            
            // $("#search-gif").show();
            $("#count2").hide();
            status='connecting';
            $("#count_denomenator").text("/"+$("#chosen-goal .goal_count").text());
            $("#gif").hide();
            $("#graph").hide();
            $("#search-gif").show();
            $.ajax({
                url:'./bluetooth_conn',
                success: function(msg){
                    if (msg.connected==false){
                        $("#connection_status").html("<span class='error'>Problem Connecting. Restart Hercubit off and restart application.</span>");
                        return
                    }
                    console.log('bluetoothconnected');
                    //Device is connected now 
                    $("#search-gif").hide();
                    $("#graph").show();
                    $("#gif").show();
                    $("#readysetgo").text('Go!');
                    $("#readysetgo").fadeOut(400);

                    //show correct gif for exercise
                    var type=$("#chosen-goal .exercise_type").text();
                    if (type=='Bicep') {$("#gif").attr('src','../static/img/bicep_curl.gif')}
                    else if (type=='Tricep') {$("#gif").attr('src','../static/img/tricep_kickbacks.gif')}
                    else if (type=='Shoulder') {$("#gif").attr('src','../static/img/shoulder_press.gif')};


                    $("#count2").fadeIn(100);
                    $("#connection_status").html("<span ></span>");
                    fetch_data = setInterval( function() { 
                        // socket.emit('get_sample');
                        
                        // request data from server at the sample rate
                        $.ajax({
                            url: './getsample',
                            success: function(msg){
                                if (msg.connected==false){
                                    $("#connection_status").html("<span class='error'>Problem Connecting. Restart Hercubit off and restart application.</span>");

                                    return
                                }
                                $("#count_numerator").html(msg.count)
                                // console.log(msg.data['accel'][1]);
                                var sample=msg.data;

                                // D3 Visualization
                                datay.push(sample['accel'][1]*1)
                                datax.push(sample['accel'][0]*1)
                                dataz.push(sample['accel'][2]*1)
                                datat.push(sample['time']*1)
                                // x.domain([0,datat+5]);

                                pathx.attr("d", line(datax))
                                pathy.attr("d", line(datay))
                                pathz.attr("d", line(dataz))
                                goal_completed()
                            }
                        })

                        if ($('#startbtn').html()=='Start'){
                            clearInterval(fetch_data);
                            finished_exercising()
                        }
                    }, msg.sampleRate*1000);

                }
            })
        }
        return false;
    });

    
    var goal_completed = function(){
        var goal_num=$("#chosen-goal .goal_count").text()*1;
        var count= $("#count_numerator").html()*1;
        if (count>=goal_num){
            $("#count_numerator").css("color",'green');
            $("#connection_status").html("<span class='success'>You rock! You reached your goal.</span>")
        }
    }

    var finished_exercising= function(){
        // socket.emit('stop');
        datax=[]
        datay=[]
        dataz=[]
        datat=[]
        // pathx.attr("d", line(datax))
        // pathy.attr("d", line(datay))
        // pathz.attr("d", line(dataz))
        // pathz.attr("d", line(datat))
        var count= $("#count_numerator").html()*1;
        $.ajax('./stop');
        // Ensure that we don't send 0 values to database
        if (count==0) {return false};
        // determineActivity();
        getNewBadge(2);
        getNewBadge(3);
        getNewBadge(4);
        getNewBadge(5);

        //Gather data about exercise session for insertion into database
        var thisgoal=$("#chosen-goal span").html();
        var type=$("#chosen-goal .exercise_type").text();
        var weight=$("#chosen-goal .goal_weight").text();
        var goal_num=$("#chosen-goal .goal_count").text()*1;
        var count= $("#count_numerator").html()*1;
        var goal_complete= "0";
        if (count>=goal_num){
            console.log('goal completed');
            goal_complete="1";
            updateFriends();
            blink($(".activeBlock"));
        }
        var username= $("#username").text();


        //add to progress viz
        new_data={
            'count': count,
            'exercise': type,
            'goal_complete': goal_complete,
            'session_time': new Date(),
            'weight': weight,
            'new':true};
        progressData.push(new_data);
        $('#progress_viz').remove();
        console.log('should have added new without refresh');
        viz(progressData);

        // progress_svg=d3.select("#chart_div")
        // var bar = progress_svg.selectAll("g")
        //     .append('g')
        //     .append('rect')
        //     .attr('x',function(d) {
        //         // console.log(d.session_time);
        //         return xScale(d3.time.day(d.session_time))
        //     });

        $.post("/addexercise",
            {'username':username,count:count,"type":type,"weight":weight,"goal_complete":goal_complete},
            function(data){
                console.log(data);
            });

        $("#count_numerator").text(0);
        $("#count_numerator").css("color",'black');
        
    }

    $("#quit").click(function(){
        $.ajax('./quit');
        console.log('quiting')
        // window.onbeforeunload = function(){}
        // window.open('','_self').close();
    })

        
    
});
