//D3 Motion Animation 
var datay = [];
var datax = [];
var dataz = [];
var datat = [];

var w = 300;
var h = 300;

var svg = d3.select("#graph")
    .append("svg")
    .attr("width", w)
    .attr("height", h)
    .attr("id", "visualization")
    .attr("xmlns", "http://www.w3.org/2000/svg");


var title = svg.append('text')
    .text('Your Motion')
    .attr({
        'x':w/3,
        'y':20,
        'color':'grey'
    });

var y = d3.scale.linear().domain([-2, 2]).range([h, 0]);
var x = d3.scale.linear().domain([0, 30]).range([0, 25]);
var line = d3.svg.line()
  .interpolate("cardinal")
  .x(function(d,i) {
    // var t=i;
    // console.log(t);
    // if (t>maxtime/2){
    //     t_diff=(maxtime/2)-t
    //     x = d3.scale.linear().domain([t_diff, maxtime+t_diff])
    // }
    return x(i);})
  .y(function(d) {return y(d);});


var pathx = svg.append("path")
  .attr("d", line(datax))
  .attr("stroke", "steelblue")
  .attr("stroke-width", "2")
  .attr("fill", "none");
var pathy = svg.append("path")
  .attr("d", line(datay))
  .attr("stroke", "green")
  .attr("stroke-width", "2")
  .attr("fill", "none");
var pathz = svg.append("path")
  .attr("d", line(dataz))
  .attr("stroke", "red")
  .attr("stroke-width", "2")
  .attr("fill", "none");
//End D3 Mortion Animation







// D3 Progress graph - moved to vis_profile.js

//dimensions of graph
// var margin = {top: 20, right: 20, bottom: 30, left: 50};
// var w_progress = $("#chart_div").width() - margin.left - margin.right;
// var h_progress = $("#chart_div").height() - margin.top - margin.bottom;

// var parseDate = d3.time.format("%Y-%m-%d %H:%M:%S").parse;


// var svg_progress = d3.select("#chart_div")
//     .append("svg")
//     .attr("width", w_progress + margin.left + margin.right)
//     .attr("height", h_progress + margin.top + margin.bottom)
//     .attr("id", "progress_viz")
//     .append("g")
//     .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


// var title_progress = svg_progress.append('text')
//     .text('Your Progress')
//     .attr({
//         'x':w*2/5,
//         'y':20
//     })

// var y_progress = d3.scale.linear()
//   // .domain([0, 200])
//   .range([h_progress, 0]);

// var x_progress = d3.time.scale()
//   .range([0, w_progress]);

// var xAxis = d3.svg.axis()
//     .scale(x_progress)
//     .orient('bottom')
//     .ticks(d3.time.days, 2)
//     .tickFormat(d3.time.format('%m/%d'))
//     .tickSize(0)
//     .tickPadding(8);

// var yAxis = d3.svg.axis()
//     .scale(y_progress)
//     .orient('left')
//     .tickPadding(8);



// var line_progress = d3.svg.line()
//   .interpolate("cardinal")
//   .x(function(d,i) {return x_progress(d.session_time);})
//   .y(function(d) {return y_progress(d.cummulative);})
//   ;


// var path_curls = svg_progress.append("rect")
//   .attr("stroke", "steelblue")
//   .attr("stroke-width", "2")
//   .attr("fill", "none");

// // var path_curls = svg_progress.append("path")
// //   .attr("stroke", "steelblue")
// //   .attr("stroke-width", "2")
// //   .attr("fill", "none");

// dates={};
// //add data to graph
// progressData=[];
// $.post("./getProgress",
//     function(data) {
//       progressData=data.progressInfo;
//       // cummulative={'Bicep':0}
//       cummulative=0

//       //Change the dates to Javascript Date objects
//       progressData.forEach(function(d) {
//         d.session_time = parseDate(d.session_time);
//       });
//       // //Sort by Dates
//       // progressData.sort(function(a, b) {return a.session_time - b.session_time})
      
      
//       // shortformat=d3.time.format("%Y%m%d");
//       progressData.forEach(function(d){
//         dates[d3.time.day(d.session_time)]=0
//       });


//       // dates={}
//       goals_complete ={'bicep':0,'tricep':0,"shoulder":0}; 
//       cummulative=0
//       progressData.forEach(function(d) {
//         //Make cumulative calculation
//         d.count = +d.count;
//         cummulative=cummulative+d.count
//         d.cummulative=cummulative

//         if (d.goal_complete=="1") {
//           goals_complete[d.exercise.toLowerCase()]+=1
//         };
//       });
//       console.log(progressData);
      
//       //total goals completed
//       total_goals_complete=0
//       for(var key in goals_complete) {
//           console.log(goals_complete[key]);
//           total_goals_complete+=goals_complete[key];
//       }

//       // Get 'Total Days Exercicised' and add it to DOM
//       total_days_exercised =0; 
//       for(var k in dates) {total_days_exercised+=1;};
//       $('#kpi').append('<span class="kpi_value">'+total_days_exercised+'</span><span class="kpi_label">Workout Days</span>')

//       $('#kpi').append('<br><span class="kpi_value">'+total_goals_complete+'</span><span class="kpi_label">Goals Completed</span>')


//       x_progress.domain(d3.extent(progressData, function(d) { return d.session_time; }));
//       y_progress.domain(d3.extent(progressData, function(d) { return d.cummulative; }));

//       path_curls.attr('d',line_progress(progressData));

//       svg_progress.append("g")
//           .attr("class", "x axis")
//           .attr("transform", "translate(0," + h_progress + ")")
//           .call(xAxis);

//       svg_progress.append("g")
//           .attr("class", "y axis")
//           .call(yAxis)
//         .append("text")
//           .attr("transform", "rotate(-90)")
//           .attr("y", 6)
//           .attr("dy", ".71em")
//           .style("text-anchor", "end")
//           .text("Total Weight lifted");

//       // progressData.forEach(function(d){
//       //     d.session_time
//       // });
//       // kpi({"daysInARow":})
//     }
// );













// var margin = {top: 20, right: 20, bottom: 30, left: 50};
// var width = $("#chart_div").width() - margin.left - margin.right;
// var height = $("#chart_div").height() - margin.top - margin.bottom;

// var x = d3.scale.ordinal()
//     .rangeRoundBands([0, width], .1);

// var y = d3.scale.linear()
//     .rangeRound([height, 0]);

// var color = d3.scale.ordinal()
//     .range(["#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);

// var xAxis = d3.svg.axis()
//     .scale(x)
//     .orient("bottom");

// var yAxis = d3.svg.axis()
//     .scale(y)
//     .orient("left")
//     .tickFormat(d3.format(".2s"));

// var svg = d3.select("#chart_div").append("svg")
//     .attr("width", width + margin.left + margin.right)
//     .attr("height", height + margin.top + margin.bottom)
//   .append("g")
//     .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// progressData=[];
// $.post("./getProgress",
//     function(data) {
//       progressData=data.progressInfo;
//       // cummulative={'Bicep':0}
//       cummulative=0
//       var parseDate = d3.time.format("%Y-%m-%d %H:%M:%S").parse;
//       //Change the dates to Javascript Date objects
//       progressData.forEach(function(d) {
//         d.session_time = parseDate(d.session_time);
//       });
//       // //Sort by Dates
//       // progressData.sort(function(a, b) {return a.session_time - b.session_time})
      
      
//       // shortformat=d3.time.format("%Y%m%d");
//       progressData.forEach(function(d){
//         // dates[d3.time.day(d.session_time)]=0
//       });

//   //mbostock's code
//     color.domain(d3.keys(data[0]).filter(function(key) { return key !== "exercise"; }));
//     data=progressData;
//     data.forEach(function(d) {
//       var y0 = 0;
//       d.exercise = color.domain().map(function(exercise) { return {exercise: exercise, y0: y0, y1: y0 += +d[exercise]}; });
//       // d.total = d.ages[d.ages.length - 1].y1;
//     });

//     data.sort(function(a, b) { return b.session_time - a.session_time; });

//     x.domain(data.map(function(d) { return d.session_time; }));
//     y.domain([0, d3.max(data, function(d) { return d.count; })]);

//     svg.append("g")
//         .attr("class", "x axis")
//         .attr("transform", "translate(0," + height + ")")
//         .call(xAxis);

//     svg.append("g")
//         .attr("class", "y axis")
//         .call(yAxis)
//       .append("text")
//         .attr("transform", "rotate(-90)")
//         .attr("y", 6)
//         .attr("dy", ".71em")
//         .style("text-anchor", "end")
//         .text("Population");

//     var state = svg.selectAll(".state")
//         .data(data)
//       .enter().append("g")
//         .attr("class", "g")
//         .attr("transform", function(d) { return "translate(" + x(d.State) + ",0)"; });

//     state.selectAll("rect")
//         .data(function(d) { return d.ages; })
//       .enter().append("rect")
//         .attr("width", x.rangeBand())
//         .attr("y", function(d) { return y(d.y1); })
//         .attr("height", function(d) { return y(d.y0) - y(d.y1); })
//         .style("fill", function(d) { return color(d.name); });

//     var legend = svg.selectAll(".legend")
//         .data(color.domain().slice().reverse())
//       .enter().append("g")
//         .attr("class", "legend")
//         .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });

//     legend.append("rect")
//         .attr("x", width - 18)
//         .attr("width", 18)
//         .attr("height", 18)
//         .style("fill", color);

//     legend.append("text")
//         .attr("x", width - 24)
//         .attr("y", 9)
//         .attr("dy", ".35em")
//         .style("text-anchor", "end")
//         .text(function(d) { return d; });

// });








// KPI graphs
// //dimensions of graph
// kpi= function(data){
//   var margin = {top: 20, right: 20, bottom: 30, left: 20};
//   var w = $("#kpi").width() - margin.left - margin.right;
//   var h = $("#kpi").height() - margin.top - margin.bottom;

//   var parseDate = d3.time.format("%Y-%m-%d %H:%M:%S").parse;


//   var svg = d3.select("#kpi")
//       .append("svg")
//       .attr("width", w_progress + margin.left + margin.right)
//       .attr("height", h_progress + margin.top + margin.bottom)
//       .attr("id", "kpi_viz")
//       .append("g")
//       .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

//   var streak = d3.select('#kpi_viz')
//       .append('text')
//       .text(data.daysInARow);


// }