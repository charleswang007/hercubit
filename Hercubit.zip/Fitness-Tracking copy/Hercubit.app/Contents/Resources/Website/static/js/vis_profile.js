/*		This script will use d3.js and Jquery to produce charts from combination static and api requested datasets from
Get Satisfaction. 

*/
var timeNow = new Date();
var format = d3.time.format("%Y/%m/%d"),
long_format = d3.time.format("%Y/%m/%d %H:%M:%S")




function viz(dataset){
	var blockTracker =new Object();
	var maxBlocks = 1;
	var blockHeight = 0;



	// console.log(dataset);


	//SVG variables
	var margin = {top: 0, right: 0, bottom: 0, left: 0};
	var width = $("#chart_div").width() - margin.left - margin.right;
	var height = $("#chart_div").height() - margin.top - margin.bottom;
	console.log(width);


	p=[10,-50,140,70],
	shortFormat = d3.time.format("%m/%d/%Y"),
	condensedFormat = d3.time.format("%y%m%d")


	// //Filter out dates
	// dataset=dataset.filter(function(d) { 
	// 		return (d.created_at.slice(0,10).split("/").join("") > 20130520) 
	// 	})
	// if (platform == "web"){
	// 	dataset=dataset.filter(function(d) { 
	// 		return (d.created_at.slice(0,10).split("/").join("") > 20130520) 
	// 	})
	// }
	// else if( platform=="mobile"){
	// 	dataset=dataset.filter(function(d) { 
	// 		return (d.created_at.slice(0,10).split("/").join("") > 20130520) 
	// 	})		
	// }
	
	//Set endpoints for the dates
	// var minDate = new Date(d3.min(dataset, function(d) { 
	//  	return format.parse(d.session_time.slice(0,10)); }))
	// var maxDate= new Date(d3.max(dataset, function(d) { 
	//  	return format.parse(d.last_active_at.slice(0,10)); }))
	// console.log("maxDate: "+maxDate)
	// if (platform=="web"){console.log(maxDate);}
	// var fullMaxDate= new Date(d3.max(dataset, function(d) { 
	//  	return long_format.parse(d.last_active_at.slice(0,19)); }))
	// console.log("fullMaxDate: "+fullMaxDate)
	 // console.log("min date is: " + shortFormat(minDate) +". And max date is: "+shortFormat(maxDate));

	//X Scale
	var xScale = d3.time.scale()
		// .domain([minDate,maxDate])
		.rangeRound([p[3],w-p[1]])
		;

  	var heightScale = d3.scale.linear()
	 .domain([0, 1])
	 .range([0, (h-(p[0]+p[2]))/maxBlocks]);


	//Create SVG element
	var svg = d3.select("#chart_div")
				.append("svg")
				.attr("width", width)
				.attr("height", height)
				.attr('id','progress_viz')
				.style('font-size', '10px')
				.append("g")
			    ;

	//Create hidden SVG element for testing
	var hidden_svg = d3.select("#chart_div")
				.append("svg")
				.attr({"width":0,"height":0})
				.append("svg:g")
			    ;


	var dayParse = d3.time.format("%Y%m%d");
	//draw bars for counting purposes only - HIDDEN




	var rect= hidden_svg.selectAll("rect")
	   .data(dataset)
	   .enter()
	   .append("rect")
	   //Stacking function: 
	   .attr("y", function(d){
	   		// console.log(blockTracker);
	   		var thisDate = dayParse(new Date (d.session_time));
	   		// console.log(thisDate);
	   		if (thisDate in blockTracker){
		   		blockTracker[thisDate]++;
		   		if (blockTracker[thisDate]>maxBlocks){maxBlocks=blockTracker[thisDate]}
	   		}
	   		else{
	   			blockTracker[thisDate]=1;
	   		}
	   		return(h-(p[0]+p[2]))-(blockTracker[thisDate]*blockHeight)})
	   .attr({"height": function(d){return heightScale(1)},
	   	      'width':"0"
		})
	   
	   ;

   extent_date=d3.extent(dataset, function(d) { return d.session_time; });
   extent_date[0]=new Date(d3.time.day(extent_date[0])-1)
   u=new Date();
   // extent_date[1]=new Date(u.setDate(u.getDate() + 1))
   extent_date[1]=u;
   xScale.domain(extent_date);
   blockHeight = (h-(p[0]+p[2]))/maxBlocks;
   console.log(maxBlocks);
   console.log(blockHeight);
   // blockHeight = 10;
   var curYpos= new Object();
   // var deltaDays = ((maxDate)-(minDate))/(3600000*24);
   var deltaDays =Math.ceil((extent_date[1]-extent_date[0])/(24*3600*1000))
   var blockWidth = (w-(p[3]+p[1]))/deltaDays


   colors=d3.scale.category10();
   console.log(colors);
	




	//Draw Bars on screen
	var draw_bars = function(s){
		filtered_dataset=dataset.filter(function(d) { 						
			// if (s=="all") {return};//get the whole dataset
			// console.log('adding this exercise to graph: '+s);
			return (d.exercise.toLowerCase() == s) 
		})

		var bar = svg.selectAll("g")
		    .data(filtered_dataset,function(d){return d.session_time})
		    .enter().append("g")
		    // .attr("transform", function(d, i) { return "translate(0," + i * barHeight + ")"; });

	    bar.append("rect")
		    .attr("x", function(d) {
		   		// console.log(d.session_time);
		   	 	return xScale(d3.time.day(d.session_time))
		    })
		    //Stacking function: 
		    .attr("y", function(d){
		   		var thisDate = dayParse(d.session_time);
		   		if (thisDate in curYpos){
		   			curYpos[thisDate]=curYpos[thisDate] + blockHeight}				   		
		   		else {curYpos[thisDate]=blockHeight}
		   		var yPos = (h-(p[2]))-(curYpos[thisDate])

		   		return yPos})

		   .attr({"height": function(d){return blockHeight},
		   	      'width':blockWidth,
		   	      'id':function(d){if (d.new==true){return "new_block"}},
		   		  "class":function(d){
		   		  		var myclass=d.exercise.toLowerCase()+" block";
		   		  		
		   		  		return myclass},
		   		  // 'alt':function(d){return d.subject},
		   		  "stroke": "white",
				  "stroke-width": 1
			})

	   // bar.append('text')
		  //  .text(function(d){
				// return d.count })
		  //  .style('color','white')
		  //  .attr("x", function(d) {
		  //  		// console.log(d.session_time);
		  //  	 	return xScale(d3.time.day(d.session_time))
		  //  })
		  //  //Stacking function: 
		  //  .attr("y", function(d){
		  //  		var thisDate = dayParse(d.session_time);
		  //  		if (thisDate in curYpos){
		  //  			curYpos[thisDate]=curYpos[thisDate] + blockHeight}				   		
		  //  		else {curYpos[thisDate]=blockHeight}
		  //  		var yPos = (h-(p[2]))-(curYpos[thisDate])

		  //  		return yPos});
	}
   	draw_bars("bicep");
   	draw_bars("tricep"); 
   	draw_bars("shoulder");
   	var displayFormat = d3.time.format("%a %b %e %Y %I:%M %p");
	//Popups
   	$('svg rect').tipsy({ 
        // gravity: function(d){
        // 	if ($(this).position().left < (w/2)){
        // 		return "w"
        // 	}
        // 	else{
	       //  	return "e"
	       //  }
        // }, 
        gravity:'w',
        html: true, 
        title: function() {
          var d = this.__data__;
          
          var popup='<p>' +d.count+' repetitions of '+ d.exercise +'</p>'+
           '<div>'+displayFormat(d.session_time) +'</div>'
          
          if (d.goals_complete!="0"){
          	var gc='completed goal'
          	popup=popup+'<img scr="checkmark.png">'
          }
          return popup; 
        }
      });


	var yScale = d3.scale.linear()
	 // .domain([0, d3.max(dataset, function(d) { return d[1]; })])
	 .domain([0, maxBlocks])
	 .range([h - p[2], p[0]]);


	//Define X axis
	var xAxis = d3.svg.axis()
	  .scale(xScale)
	  .orient("bottom")
	  .ticks(d3.time.days, 1)//tick every 7 days
	  .tickFormat(d3.time.format("%b %d"))
	  ;

	//Define Y axis
	var yAxis = d3.svg.axis()
					  .scale(yScale)
					  .orient("left")
					  .ticks(5)
					  // .attr('transform',"translate(5)")
					  ;

	//this positions the labels perfectly
	var label_adjustment=blockWidth/3;
	//Create X axis
	svg.append("g")
		.attr("class", "axis")
		.attr("transform", "translate(0," + (h - p[2]) + ")")
		.call(xAxis)
		.selectAll("text")  
            .style("text-anchor", "end")
            .attr({"dx": label_adjustment,
            	   "dy": label_adjustment,
            	   "class": "axis-label axis-text x-axis-label",
				   "transform": function(d) {
                return "rotate(-45)" 
            }});
	
	//Create Y axis
	svg.append("g")
		.attr("class", "axis")
		.attr("transform", "translate(" + ((1*p[3])) + ",0)")
		.call(yAxis);
	
	//Y Axis Label
	svg.append('text')
		.text("Sets")
		.attr({
			"class":"axis-label",
			"transform":"translate("+ (p[3]-60)+","+((h)/3)+") ",
			// "font-size":16
		})
		.style('font-size', '16px');

	//Chart Title
	var chartTitle = svg.append("text")
		// .text('Progress')
		.attr("transform","translate("+(w/3)+",30)")	


	


	/*
	"Key"
		This component is a key or legend that appears below each stacked bar chart.
		Consists of rectangles and text labels
	*/
	// var chartKey = svg.append("g")
	// 	.attr("class","chartKey")
	// 	.attr("transform","translate(10,0)")

	// var key_spacing=20;

	
	// chartKey.append("rect")
	// 	.attr({
	// 		"transform":"translate(0,0)",
	// 		"height": blockHeight,
	// 		"width":blockWidth,
	// 		"class": "bicep block" 
	// 	})
	// chartKey.append("rect")
	// 	.attr({
	// 		"transform":"translate("+blockWidth*1.1+",0)",
	// 		"height": blockHeight,
	// 		"width":blockWidth,
	// 		"class": "tricep block" 
	// 	})
	// chartKey.append("rect")
	// 	.attr({
	// 		"transform":"translate("+blockWidth*2.2+",0)",
	// 		"height": blockHeight,
	// 		"width":blockWidth,
	// 		"class": "shoulder block" 
	// 	})
	// chartKey.append("text")
	// 	.text("bicep")
	// 	.attr("transform","translate(0,7)")
	// 	.attr("class","legend-text");
	// chartKey.append("text")
	// 	.text("tricep")
	// 	.attr("transform","translate("+blockWidth*1.1+",7)")
	// 	.attr("class","legend-text");
	// chartKey.append("text")
	// 	.text("shoulder")
	// 	.attr("transform","translate("+blockWidth*2.2+",7)")
	// 	.attr("class","legend-text");
					

	//this allows them to be clickable
	bindBlockEvents()
	blink($('#new_block'));
}//End visualization formula
progressData=[]		


var blink= function(el){
	//'''Make the new block blink so it is noticed'''

	var speed = 750;
	el.animate({
		opacity:.05
	},speed,function(){
		el.animate({
			opacity:1
		},speed,function(){
			el.animate({
				opacity:.05
			},speed,function(){
				el.animate({
					opacity:1
				},speed,function(){
					el.animate({
						opacity:.05
					},speed,function(){
						el.animate({
							opacity:1
						},speed)

					})
				})
			})
		})
	})

}



$(document).ready(function(){

	//Fade others on click 
	bindBlockEvents = function(){
		$(".block").hover(function(){

			$(this).attr({'stroke':"lightblue",
						  'stroke-width':2});
		},function(){
			$(this).attr({'stroke':"white",
						  'stroke-width':1})}
		);

		$('.block').click( function () {
				if($(this).attr("highlighted")=='true'){
					//unhide if clicked while already hightlighted
					$('rect, circle').each(function(i, val){ 
						$(val).fadeTo(200, 1);
						$(val).attr("highlighted",false);
					})
				}
				else{
					target = $(this).attr('class');
					$('.block, circle').each(function(i, val){ 
						if ( val.className.animVal !== target )
						{ 
							$(val).fadeTo(200, 0.1);
						}
						else 
						{
							$(val).fadeTo(200, 1);
							$(val).attr("highlighted",true)
						}
					})
				}
		})

		//UnFade all on SVG click
		 $('svg').click(function(){
		 	if (event.target == this){
			 	$('rect').each(function(i, val){ 
					$(val).fadeTo(200, 1);
					$(val).attr("highlighted",false);
				})
			}
		});
	}



	// var weekAgo = timeNow.getSeconds() - (1*24*3600)
	// var sinceLaunch=1369094400 //May 21, 2013 12:00AM
	// var lastDatasetDate = d3.max(webdataset, function(d) { 
	// 	 	return long_format.parse(d.last_active_at.slice(0,19)); })
	// lastDatasetDate = (lastDatasetDate.getTime()/1000)+1
	// // console.log(long_format(lastDatasetDate))
	// var lastMobileDatasetDate = d3.max(mobiledataset, function(d) { 
	// 	 	return long_format.parse(d.last_active_at.slice(0,19)); })
	// lastMobileDatasetDate = (lastMobileDatasetDate.getTime()/1000)+1
	
	
	// Fetch Data for Viz and Call Viz function
	dates={};
	progressData=[];
	$.post("./getProgress",
	    function(data) {
	      progressData=data.progressInfo;
	      // cummulative={'Bicep':0}
	      cummulative=0
	      var parseDate = d3.time.format("%Y-%m-%d %H:%M:%S").parse;
	      //Change the dates to Javascript Date objects
	      progressData.forEach(function(d) {
	        d.session_time = parseDate(d.session_time);
	      });
	      // //Sort by Dates
	      // progressData.sort(function(a, b) {return a.session_time - b.session_time})
	      
	      
	      // shortformat=d3.time.format("%Y%m%d");
	      progressData.forEach(function(d){
	        dates[d3.time.day(d.session_time)]=0
	      });

	      goals_complete ={'bicep':0,'tricep':0,"shoulder":0}; 
	      cummulative=0
	      progressData.forEach(function(d) {
	        //Make cumulative calculation
	        d.count = +d.count;
	        cummulative=cummulative+d.count
	        d.cummulative=cummulative

	        if (d.goal_complete=="1") {
	          goals_complete[d.exercise.toLowerCase()]+=1
	        };
	      });
	      console.log(progressData);
	      
	      //total goals completed
	      total_goals_complete=0
	      for(var key in goals_complete) {
	          // console.log(goals_complete[key]);
	          total_goals_complete+=goals_complete[key];
	      }

	      // Get data for KPIs and add it to DOM
	      total_days_exercised =0; 
	      for(var k in dates) {total_days_exercised+=1;};
	      $('#kpi').append('<span class="kpi_value">'+total_days_exercised+'</span><span class="kpi_label">Workout Days</span>')

	      $('#kpi').append('<br><span class="kpi_value">'+total_goals_complete+'</span><span class="kpi_label">Goals Completed</span>')

	      viz(progressData);
	    }
	);



})//end $(document).ready function
		
		