// Backend info
// var username = "kate";

var badgeName = ["Newbie","Goal","Strike3","Strike7","Five","Completion"];
var badgeDesc = ["Signed up for Hercubit!", "Set your first goal!","3-day Strike!","7-day Strike!","Five sessions!","Complete your first exercise!"];
var badgeArray = [0,0,0,0,0,0];
var flagFTG = 0;

var activityArray = [0,0,0,0,0,0,0];
var startDate = new Date("2014-04-09");

var friendArray = [];

var workout_days = 10;
var goal_completion = 90;
var rank_percentile = 10;

$(document).ready(function () {
  
  $("#readysetgo").hide();
  $("#connection_status").hide();
  $("#search-gif").hide();

  $("#help").click(function(){
    showIntroOverlay();
  });

  $("#intro-overlay").click(function(){
    console.log("click on intro overlay");
    $("#intro-overlay").hide();
    getNewBadge(0);
  });

    /* If first time use */
    var firstTimeUse = 1;

    $(".plusminusbtn").click(function(){
      console.log($(this).text());
      var sum=$(this).siblings('input').val()*1+$(this).text()*1;
      if (sum<0){
        sum=0;
      }
      $(this).siblings('input').val(sum);
    })


    if ($("#username").html()!='') {
        console.log('user already logged in as: '+ $("#username").text())
        firstTimeUse=false;
    }
    if (firstTimeUse) {
        $("#white-overlay").show();
        $("#signup-form").show();
        $("header div.header-action").hide();
    }


    $("#signup").submit(function(e){
        $("#white-overlay").hide();
        $("#signup-form").hide();
        $("header div.header-action").show();
        e.preventDefault();
        $("#username").text($("#username").text().toLowerCase());
        signup();
        
    });


    function signup(){
      $.post("./signup",
        $("#signup").serialize(),
        function(data){
            console.log('signup');
            console.log(data.new_user);
          if(data.new_user == false){
            console.log("old user");
            window.onbeforeunload = function(){}
            window.location.href= "/";
          }
          else{
            console.log('checking for new user')
            //
            showIntroOverlay();
            //
            //getNewBadge(0);
          }
      
          return false;
        }
      )}

    //When the user clicks logout call logout in app.py and delete cookie
    // then refresh when python sends the success response
    $("#logout").click(function(){
        logout();
    });
    function logout(){
            $.post("./logout",
                function(data){
                    console.log('successful logout');

                    //send the user back to the log in screen by refreshing.
                    window.onbeforeunload = function(){}
                    window.location.href ="/";
                }
                
        );
        
        return false;

    }

    /* Start */
    /************************************************************************/
    // var t = $("section.main .card").position().top + 250;
    // $("#startbtn").css({top:t, left:"50%", position:"fixed", "margin-left":"-100px"});

  	// Click Start to see count
  	$("#startbtn").on('click', function(){
  		if ($("section.metadata").attr('data-state') === 'neutral') {
              $("#count").show();
              $("#readysetgo").show();
              $("#connection_status").show();
              $("#search-gif").show();
              $("section.metadata").attr('data-state', 'slide-out');
              $("section.social").attr('data-state', 'slide-out');
              $("section.main .card").attr('data-state', 'slide-out');
              $("section.main #count").attr('data-state', 'slide-out');
              $("#startbtn").attr('data-state', 'slide-out');
              $("#startbtn").text("Done");

              var t = $("#count2").position().top + 250;
              $("#startbtn").css({top:t, left:"50%", position:"fixed", "margin-left":"-100px"});
          } 
          else {
              if (status=='connecting') {$("#count2").show()};

              $("#count").hide();
              $("#readysetgo").hide();
              $("#connection_status").hide();
              $("#search-gif").hide();
              $("section.metadata").attr('data-state', 'neutral');
              $("section.social").attr('data-state', 'neutral');
              $("section.main .card").attr('data-state', 'neutral');
              $("section.main #count").attr('data-state', 'neutral');
              $("#startbtn").attr('data-state', 'neutral');
              $("#startbtn").text("Start");

              var t = $("section.main .card").position().top + $("section.main .card").height() + 50;
              $("#startbtn").css({top:t, left:"50%", position:"fixed", "margin-left":"-100px"});
              
          }
  	});

    /* Goal */
    /************************************************************************/
    updateGoals();

    /* Activity */
    /************************************************************************/
    //getActivities();


    /* Friends */
    /************************************************************************/
    // TODO: Loop through database to get friend list
    getFriends();

    /* Comment off for hiding the Message & Challenge buttons */
    // $("html").on("click", function(){
    //     $("div.friend").css("height", "80px");
    //     $("div.friend").find("div.menu").hide();
    // })
    // $("div.friend").on("click", function(e){
    //     e.stopPropagation();
    //     $("div.friend").css("height", "80px");
    //     $("div.friend").find("div.menu").hide();
    //     $(this).css("height","160px");
    //     $(this).find("div.menu").show();
    // });


    /* Achievements */
    checkBadge();
	


    //Show exercise .gif based on which is selected.
    $("#pick_exercise").change(function(){
      console.log($("#pick_exercise").val());
      if($("#pick_exercise").val()=='Tricep'){
        $("#goal_pic_gif").html('<img src="../static/img/tricep_kickbacks.gif">');
      }
      else if($("#pick_exercise").val()=='Bicep'){
       $("#goal_pic_gif").html('<img src="../static/img/bicep_curl.gif">'); 
      }
      else if($("#pick_exercise").val()=='Shoulder'){
       $("#goal_pic_gif").html('<img src="../static/img/shoulder_press.gif">');  
      }
    });






});



//show count as user moves slider in goal addition
$("#exerciseCountform").change(function(){
  console.log(this.val());
  $("#showexercisecount").text($("#exerciseCountform").val())
});

function showIntroOverlay() {
  $("#intro-overlay").show();
  $("#intro-badge").offset($("#achievements").position());
  $("#intro-badge").css("height",$("#achievements").height());
  $("#intro-badge").css("width",$("#achievements").width());
  $("#intro-badge").css("margin", $("#achievements").css("margin"));

  $("#intro-performance").offset($("#performance").position());
  $("#intro-performance").css("height",$("#performance").height());
  $("#intro-performance").css("width",$("#performance").width());
  $("#intro-performance").css("margin", $("#performance").css("margin"));

  $("#intro-goal").offset($("section.main").position());
  $("#intro-goal").css("height","550px");
  $("#intro-goal").css("width",$("section.main").width());
  $("#intro-goal").css("margin", $("section.main").css("margin"));
  $("#intro-goal").css("margin-top", $("#achievements").css("margin-top"));

  $("#intro-friendlist").offset($("#friendlist").position());
  // $("#intro-friendlist").css("height",$("#friendlist").height());
  $("#intro-friendlist").css("height","550px");
  $("#intro-friendlist").css("width",$("#friendlist").width());
  // $("#intro-friendlist").css("margin", $("#friendlist").css("margin"));
  $("#intro-friendlist").css("margin", "30px");
}


function updateGoals() {
  $("div.goal").hover(
      function() {
          $(this).children(".trash").attr('data-state', 'hover');
      },
      function() {
          $(this).children(".trash").attr('data-state', 'neutral');
      }
  );
  // Click to delete the goal
  $("div.goal .trash").on('click', function(){
      // console.log($(this).parent()[0].id);
    
      $.post ("/deleteGoal",
        { id: $(this).parent()[0].id },
        // $("#modal-add-goal").serialize(),
        function(data) {
          console.log("delete goal");
          window.onbeforeunload = function(){}
          window.location.href = "/";
        }
      );
      // e.preventDefault();

  });
  // Click to choose the goal
  $("div.goal").on('click', function(){
      if (this.id!=="add-goal") {
          $("#chosen-goal span").html($(this).find('div.num').text() +": "+ $(this).find('div.desc').html())
          $(".goal").removeClass("selected");
          $(this).addClass("selected");
          $("#startbtn").removeClass("disable");
      }
  });

  // If no goal is chosen, choose the first goal and highlight it
  if ($(".goal.selected").length==0 && $(".goal").length>1) {
    $(".goal").first().addClass("selected");
    $("#chosen-goal span").html($(".goal").first().find('div.num').text() +": "+ $(".goal").first().find('div.desc').html())
    $("#startbtn").removeClass("disable");
  }


  // Pop up Modal after clicking on Add goal
  $("#add-goal").on('click', function(){
      $("#modal-overlay").show();
      $("#modal-goal").show();
  });
  $("#modal-overlay").on('click', function(){
      $("#modal-overlay").hide();
      $("#modal-goal").hide();
      $("#modal-badge").hide();
      if (flagFTG==1) {
        window.onbeforeunload = function(){}
        window.location.href = "/"; 
      }
  });
  $("#modal-add-goal").submit(function(e){
      $("#modal-overlay").hide();
      $("#modal-goal").hide();

      $.post ("/addGoal",
        $("#modal-add-goal").serialize(),
        function(data) {
          console.log("post addGoal");
          // TODO: FIX the disappearing modal window

          // seems to be fixed..


          getNewBadge(1);
        }
      );

      e.preventDefault();

  });
}

function getFriends() {

  $.post("/getFriendActivities",
    { username: "" },
    function(data) {
      friendArray = data;
      updateFriends();
    }
  );
}

function updateFriends() {
  console.log("UPDATE FRIENDS");
  // Empty first
  //$("section.social div.card").empty();
  $("section.social div.card .friend").remove()

  for (var i=1; i<friendArray['userInfo'].length+1; i++) {

    // Add friend list
    $("section.social div.card").append('<div class="friend lines clear" id="friend-'+friendArray['userInfo'][i-1]['username']+'"><div class="left"><div class="icon"><img src="../static/img/'+friendArray['userInfo'][i-1]['username']+'.png"></div></div><div class="right"><div class="name">'+friendArray['userInfo'][i-1]['username']+'</div><div class="menu" id="menu'+i+'"></div></div></div>');
    // Highlight myself & the most recent block
    var username = $("#username").text();
    $("#friend-"+username).css("background-color","#98C0F1");
    $("#friend-"+username+" .menu .code").last().addClass("activeBlock");

    // Add activity blocks
    var score = 0;
    for (var k=0; k<7; k++) {
      // Add block
      var code = '<div class="code" id="code-'+i+k+'"></div>';
      $("#menu"+i).append(code);
      if (friendArray['userInfo'][i-1]['act'][k]['Total']>3) {
        $("#code-"+i+k).addClass("level-3");
      }
      else {
        $("#code-"+i+k).addClass("level-"+friendArray['userInfo'][i-1]['act'][k]['Total']);
      }

      // Add hover state of the block
      $("#code-"+i+k).hover((function(i,k){
        return function(){
          $("#tooltip-code").html("<p>"+friendArray['userInfo'][i-1]['act'][k]['Total']+" exercise</p><p>"+friendArray['userInfo'][i-1]['act'][k]['Bicep']+" Bicep<br/>"+friendArray['userInfo'][i-1]['act'][k]['Tricep']+" Tricep<br/>"+friendArray['userInfo'][i-1]['act'][k]['Shoulder']+" Shoulder<br/>"+"</p>");
          $("#tooltip-code").css("top", $(this).position().top-50);
          $("#tooltip-code").css("left", $(this).position().left-1000);
          $("#tooltip-code").show();
        }
      })(i,k),
      (function(i,k){
        return function(){
          $("#tooltip-code").hide();
        }
      })(i,k));

      // Calculate score to sort the rank
      score += friendArray['userInfo'][i-1]['act'][k]['Total'];
    }
    // Add score
    $("#friend-"+friendArray['userInfo'][i-1]['username']).attr("score",score);
    $("#friend-"+friendArray['userInfo'][i-1]['username']).append('<div class="score">'+score+'</div>');

    
  }

  // Sort friend list based on score
  $(".friend").sortElements(function(a, b){
    return parseInt($(a).attr('score')) < parseInt($(b).attr('score')) ? 1 : -1;
  });
  // Add rank
  $(".friend").children(".left").prepend(function(){
    var r = parseInt($(this).parent().index())-1;
    return '<div class="num">'+r+'</div>'; 
  });

}




function getActivities() {
  $.post("/getActivities",
    function(data) {
      // console.log(data);
      for (var i=0; i<7; i++) {
        activityArray[i] = data['userInfo']['act_day'+i];
      }
      console.log("activityArray: "+activityArray);
      for (var i=1; i<activityArray.length+1; i++) {
        var code = '<div class="code" id="code-'+i+'"></div>';
        $("#activity-map").append(code);
        $("#code-"+i).addClass("level-"+activityArray[i-1]);
      }

    }
  );  
}

function determineActivity() {
  $.post("/determineActivity",
    function(data) {
      // console.log(data);
      var todayDate = new Date();
      var diff = new Date(todayDate-startDate);
      diff = Math.floor(diff/1000/60/60/24);
      console.log("diff"+diff);
      var e = data['activityInfo']['E'];
      var g = data['activityInfo']['G'];
      var level = 0;

      if (e==0) {
        level = 0;
      }
      else if (e<g) {
        level = 1;
      }
      else if (e==g) {
        level = 2;
      }
      else if (e>g) {
        level = 3;
      }
      else {
        level = 0;
        console.log("Something wrong with activity map");
      }
      activityArray[diff] = level;
      for (var i=1; i<activityArray.length+1; i++) {
        var code = '<div class="code" id="code-'+i+'"></div>';
        $("#activity-map").append(code);
        $("#code-"+i).addClass("level-"+activityArray[i-1]);
      }

      updateActivity(diff, level);
    }
  );    
}

function updateActivity(diff, level) {
  console.log("updateActivity, diff="+diff);
  $.post("/updateActivity",
    { diff: diff,
      level: level },
    function(data) {
      console.log("updateActivity success");
    }
  );
}

function checkBadge() {
  $.post("/checkBadge",
    function(data) {
      console.log(data)
      for (var i=1; i<7; i++) {
        badgeArray[i-1] = data['userInfo']['badge'+i];
      }
      updateBadge(); 
    }
  )
};

function updateBadge() {
  for (var i=1; i<7; i++) {
    // badge already get
    if (badgeArray[i-1]==1) { 
      $("#badge"+i+" img").attr("src","../static/img/"+badgeName[i-1]+".png");
    }
    else { 

    }
    $("#badge"+i).hover((function(i){
      return function(){
        $(".tooltip").html("<p>"+badgeName[i-1]+"</p><p>"+badgeDesc[i-1]+"</p>");
        $(".tooltip").css("top", $(this).position().top+20);
        $(".tooltip").css("left", $(this).position().left);
        $(".tooltip").show();
      }
    })(i),
    (function(i){
      return function(){
        $(".tooltip").hide();
      }
    })(i));
  }
}


function getNewBadge (badgeNum) {
  checkBadge();
  // console.log(badgeNum);
  // console.log(badgeArray[badgeNum]);
  if (badgeArray[badgeNum]==0) {
    // doesn't have the badge
    // put sql determine call here
    determineBadge(badgeNum);
  }
  if (badgeArray[1]==1 && badgeNum==1) {
    window.onbeforeunload = function(){}
    window.location.href = "/"; 
  }

}

function determineBadge (badgeNum) {
  $.post("/determineBadge",
    { badgeNum: badgeNum },
    function(data) {

      if (data['badgeInfo']['st']==1 || badgeNum==0) {
        $("#modal-badge").find("h1").text(badgeName[badgeNum]);
        $("#modal-badge").find("img").attr("src","../static/img/"+badgeName[badgeNum]+".png");
        $("#modal-badge").find("span").text("You've " + badgeDesc[badgeNum]);
        $("#modal-overlay").show();
        $("#modal-badge").show();
        $("#modal-badge").addClass("animated bounceIn");
        if (badgeNum==1) {
          flagFTG = 1;
        }

        insertBadge(badgeNum);
      }
    }
  )  
}

function insertBadge(badgeNum) {
  badgeNum = badgeNum + 1;

  $.post("/insertBadge",
    { badgeNum: badgeNum },
    function(data) {
      checkBadge();
    }
  );
};

function forTooltip(i) {
  return function() {
    return badgeName[i-1];
  }
}

    /* Performance Gauge */
    // drawChart()
// Gauges for progress
// function drawChart() {
// 	var data = google.visualization.arrayToDataTable([
//           ['Label', 'Value'],
//           ['Workout Days', workout_days],
// 		  ['Goal Complete %', goal_completion],
//           ['Rank Percentile', rank_percentile]
//         ]);

//         var options = {
//           width: 400, height: 120,
//           redFrom: 80, redTo: 100,
//           yellowFrom:60, yellowTo: 80,
//           minorTicks: 5,
//         };

//         var chart = new google.visualization.Gauge(document.getElementById('chart_div'));
//         chart.draw(data, options);
// }



// window.onbeforeunload = function(){
//     return "Please instead click 'Quit' in the top right to exit and allow the application to shutdown as well. Thank you.";
// }

// Sorting Functions
jQuery.fn.sortElements = (function(){
 
    var sort = [].sort;
 
    return function(comparator, getSortable) {
 
        getSortable = getSortable || function(){return this;};
 
        var placements = this.map(function(){
 
            var sortElement = getSortable.call(this),
                parentNode = sortElement.parentNode,
 
                // Since the element itself will change position, we have
                // to have some way of storing its original position in
                // the DOM. The easiest way is to have a 'flag' node:
                nextSibling = parentNode.insertBefore(
                    document.createTextNode(''),
                    sortElement.nextSibling
                );
 
            return function() {
 
                if (parentNode === this) {
                    throw new Error(
                        "You can't sort elements if any one is a descendant of another."
                    );
                }
 
                // Insert before flag:
                parentNode.insertBefore(this, nextSibling);
                // Remove flag:
                parentNode.removeChild(nextSibling);
 
            };
 
        });
 
        return sort.call(this, comparator).each(function(i){
            placements[i].call(getSortable.call(this));
        });
 
    };
 
})();
