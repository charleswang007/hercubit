import peak_detect

while True:
	reps = peak_detect.detect_rep()
	if reps!= None:
		print reps
	